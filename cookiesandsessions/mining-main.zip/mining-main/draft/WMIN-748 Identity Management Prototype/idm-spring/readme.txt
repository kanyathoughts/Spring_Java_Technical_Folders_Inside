http://localhost:8080/api/public/projects/4711

http://localhost:8080/api/v1/projects/4711/discovery/admin
http://localhost:8080/api/v1/projects/4711/discovery/manager
http://localhost:8080/api/v1/projects/4711/discovery/editor
http://localhost:8080/api/v1/projects/4711/discovery/viewer
http://localhost:8080/api/v1/projects/4711/minining/admin
http://localhost:8080/api/v1/projects/4711/minining/manager
http://localhost:8080/api/v1/projects/4711/minining/editor
http://localhost:8080/api/v1/projects/4711/minining/viewer

http://localhost:8080/api/v1/projects/4712/discovery/admin
http://localhost:8080/api/v1/projects/4712/discovery/manager
http://localhost:8080/api/v1/projects/4712/discovery/editor
http://localhost:8080/api/v1/projects/4712/discovery/viewer
http://localhost:8080/api/v1/projects/4712/minining/admin
http://localhost:8080/api/v1/projects/4712/minining/manager
http://localhost:8080/api/v1/projects/4712/minining/editor
http://localhost:8080/api/v1/projects/4712/minining/viewer
