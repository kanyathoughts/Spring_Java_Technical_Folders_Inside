# How to use

```
mining-call-chain-consolidator file1.csv file2.csv ...
```
Will create a file named `file1_consolidated.csv`.

# How to build

```
npm install
npm run build
npm run pkg
```
Executables will be in the `bin/` folder.