/* Copyright (c) 2023 innoWake gmbh Germany. All rights reserved. */
package innowake.mining.shared.model.datalineage.util;

import innowake.mining.shared.model.datalineage.graph.DataFlowGraphNode;

public class Copybook extends Element {

    public Copybook(final DataFlowGraphNode node) {
        super(node);
    }
}
