package innowake.mining.shared.model.datalineage.util;

import innowake.mining.shared.model.datalineage.graph.DataFlowGraphNode;

public class DataInterface extends Element {

	public DataInterface(final DataFlowGraphNode node) {
		super(node);
	}
	
}
