package innowake.mining.shared.model.datalineage.util;

import innowake.mining.shared.model.datalineage.graph.DataFlowGraphNode;

public class DataInterfaceGroup extends Module {
	
	public DataInterfaceGroup(final DataFlowGraphNode node) {
		super(node);
	}
}
