package innowake.mining.shared.model.datalineage.util;

import innowake.mining.shared.model.datalineage.graph.DataFlowGraphNode;

public class Field extends Element {

	public Field(final DataFlowGraphNode node) {
		super(node);
	}
}
