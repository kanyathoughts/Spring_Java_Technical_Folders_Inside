/*
 * Copyright (c) 2021 innoWake gmbh Germany. All rights reserved.
 */
package innowake.mining.extensions.discovery.featurereport.model;
public enum Supported {
	YES,
	NO,
	SOMETIMES;
}