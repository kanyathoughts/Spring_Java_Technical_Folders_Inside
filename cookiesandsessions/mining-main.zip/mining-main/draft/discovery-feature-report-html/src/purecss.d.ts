declare module "purecss" {
  function getFile(name: string): string;
  function getFilePath(name: string): string;
}