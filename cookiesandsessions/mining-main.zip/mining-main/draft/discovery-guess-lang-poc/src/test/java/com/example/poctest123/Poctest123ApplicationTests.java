package com.example.poctest123;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Poctest123ApplicationTests {

	@Test
	void contextLoads() {
	}

}
