.. toctree::
  :hidden:

  contents
  guesslang

.. include:: contents.rst
