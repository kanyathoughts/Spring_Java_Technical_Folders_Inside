
Guesslang package reference
===========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

guesslang.Guess
---------------

.. autoclass:: guesslang.Guess
   :members:

guesslang.GuesslangError
------------------------

.. automodule:: guesslang.GuesslangError
