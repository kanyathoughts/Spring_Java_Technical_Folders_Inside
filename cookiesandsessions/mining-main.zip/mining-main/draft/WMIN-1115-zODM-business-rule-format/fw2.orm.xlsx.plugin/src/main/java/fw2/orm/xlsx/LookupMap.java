/**
 */
package fw2.orm.xlsx;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lookup Map</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.orm.xlsx.XlsxPackage#getLookupMap()
 * @model
 * @generated
 */
public interface LookupMap extends ReferenceMap {
} // LookupMap
