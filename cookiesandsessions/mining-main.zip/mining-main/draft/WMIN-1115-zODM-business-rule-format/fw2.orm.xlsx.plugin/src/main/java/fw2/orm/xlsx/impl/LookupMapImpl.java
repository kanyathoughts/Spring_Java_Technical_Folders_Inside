/**
 */
package fw2.orm.xlsx.impl;

import fw2.orm.xlsx.LookupMap;
import fw2.orm.xlsx.XlsxPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lookup Map</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LookupMapImpl extends ReferenceMapImpl implements LookupMap {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LookupMapImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return XlsxPackage.Literals.LOOKUP_MAP;
	}

} //LookupMapImpl
