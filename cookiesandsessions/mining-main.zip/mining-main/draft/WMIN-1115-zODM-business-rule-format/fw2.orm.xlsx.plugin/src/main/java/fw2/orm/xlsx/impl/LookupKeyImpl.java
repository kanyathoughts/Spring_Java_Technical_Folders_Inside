/**
 */
package fw2.orm.xlsx.impl;

import fw2.orm.xlsx.LookupKey;
import fw2.orm.xlsx.XlsxPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lookup Key</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LookupKeyImpl extends ReferenceKeyImpl implements LookupKey {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LookupKeyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return XlsxPackage.Literals.LOOKUP_KEY;
	}

} //LookupKeyImpl
