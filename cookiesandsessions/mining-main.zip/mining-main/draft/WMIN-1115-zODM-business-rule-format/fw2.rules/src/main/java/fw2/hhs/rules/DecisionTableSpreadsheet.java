package fw2.hhs.rules;

public class DecisionTableSpreadsheet {
	private String excelLocation;
	private String excelFileName;
	public String getExcelLocation() {
		return excelLocation;
	}
	public void setExcelLocation(String excelLocation) {
		this.excelLocation = excelLocation;
	}
	public String getExcelFileName() {
		return excelFileName;
	}
	public void setExcelFileName(String excelFileName) {
		this.excelFileName = excelFileName;
	}

}
