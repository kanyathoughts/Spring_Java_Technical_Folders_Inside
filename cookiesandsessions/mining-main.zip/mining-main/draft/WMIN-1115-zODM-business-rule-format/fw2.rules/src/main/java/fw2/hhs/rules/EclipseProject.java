package fw2.hhs.rules;
public class EclipseProject {

	String repositoryLocation;
	String projectName;


	public String getRepositoryLocation() {
		return repositoryLocation;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public void setRepositoryLocation(String repositoryLocation) {
		this.repositoryLocation = repositoryLocation;
	}



}
