package fw2.hhs.decisiontables;

public class DecisionTableRow {

}
