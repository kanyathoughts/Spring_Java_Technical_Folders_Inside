package fw2.hhs.decisiontables;

public class ConditionColumn {
	private String columnName;
	private String columnTerm;
	 

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnTerm() {
		return columnTerm;
	}

	public void setColumnTerm(String columnTerm) {
		this.columnTerm = columnTerm;
	}

}
