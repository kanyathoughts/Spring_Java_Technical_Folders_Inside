/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getPrimitive()
 * @model extendedMetaData="name='primitive' kind='elementOnly'"
 * @generated
 */
public interface Primitive extends Attribute {
} // Primitive
