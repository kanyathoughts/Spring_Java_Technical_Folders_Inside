/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Db Data Set</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getDbDataSet()
 * @model abstract="true"
 *        extendedMetaData="name='dbDataSet' kind='elementOnly'"
 * @generated
 */
public interface DbDataSet extends ModelElement {
} // DbDataSet
