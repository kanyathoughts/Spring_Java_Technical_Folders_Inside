/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getAttribute()
 * @model abstract="true"
 *        extendedMetaData="name='attribute' kind='elementOnly'"
 * @generated
 */
public interface Attribute extends ModelElement {
} // Attribute
