/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Db View Column</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getDbViewColumn()
 * @model extendedMetaData="name='dbViewColumn' kind='elementOnly'"
 * @generated
 */
public interface DbViewColumn extends ModelElement {
} // DbViewColumn
