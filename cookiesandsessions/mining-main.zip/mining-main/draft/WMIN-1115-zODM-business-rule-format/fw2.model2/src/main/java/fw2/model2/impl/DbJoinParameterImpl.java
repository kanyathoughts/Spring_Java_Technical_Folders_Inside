/**
 */
package fw2.model2.impl;

import fw2.model2.DbJoinParameter;
import fw2.model2.Model2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Db Join Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DbJoinParameterImpl extends ModelElementImpl implements DbJoinParameter {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected DbJoinParameterImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.DB_JOIN_PARAMETER;
    }

} //DbJoinParameterImpl
