/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Db Join Key</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getDbJoinKey()
 * @model extendedMetaData="name='dbJoinKey' kind='elementOnly'"
 * @generated
 */
public interface DbJoinKey extends ModelElement {
} // DbJoinKey
