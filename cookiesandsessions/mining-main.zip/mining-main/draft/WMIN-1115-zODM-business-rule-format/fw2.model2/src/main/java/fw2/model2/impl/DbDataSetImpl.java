/**
 */
package fw2.model2.impl;

import fw2.model2.DbDataSet;
import fw2.model2.Model2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Db Data Set</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class DbDataSetImpl extends ModelElementImpl implements DbDataSet {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected DbDataSetImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.DB_DATA_SET;
    }

} //DbDataSetImpl
