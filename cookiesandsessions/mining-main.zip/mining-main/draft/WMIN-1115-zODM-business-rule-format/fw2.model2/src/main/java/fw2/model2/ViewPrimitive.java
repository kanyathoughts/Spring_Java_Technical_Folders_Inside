/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>View Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getViewPrimitive()
 * @model abstract="true"
 *        extendedMetaData="name='viewPrimitive' kind='elementOnly'"
 * @generated
 */
public interface ViewPrimitive extends ViewElement {
} // ViewPrimitive
