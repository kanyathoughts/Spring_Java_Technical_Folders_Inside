/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Db Join Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getDbJoinParameter()
 * @model extendedMetaData="name='dbJoinParameter' kind='elementOnly'"
 * @generated
 */
public interface DbJoinParameter extends ModelElement {
} // DbJoinParameter
