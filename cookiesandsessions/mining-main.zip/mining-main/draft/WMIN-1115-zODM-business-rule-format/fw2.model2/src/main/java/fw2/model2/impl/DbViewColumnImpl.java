/**
 */
package fw2.model2.impl;

import fw2.model2.DbViewColumn;
import fw2.model2.Model2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Db View Column</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DbViewColumnImpl extends ModelElementImpl implements DbViewColumn {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected DbViewColumnImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.DB_VIEW_COLUMN;
    }

} //DbViewColumnImpl
