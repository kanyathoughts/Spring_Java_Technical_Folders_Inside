/**
 */
package fw2.model2.impl;

import fw2.model2.Model2Package;
import fw2.model2.Primitive;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimitiveImpl extends AttributeImpl implements Primitive {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected PrimitiveImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.PRIMITIVE;
    }

} //PrimitiveImpl
