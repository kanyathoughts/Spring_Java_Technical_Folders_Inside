/**
 */
package fw2.model2.impl;

import fw2.model2.Model2Package;
import fw2.model2.ViewPrimitive;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>View Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ViewPrimitiveImpl extends ViewElementImpl implements ViewPrimitive {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected ViewPrimitiveImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.VIEW_PRIMITIVE;
    }

} //ViewPrimitiveImpl
