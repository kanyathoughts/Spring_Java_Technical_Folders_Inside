/**
 */
package fw2.model2.impl;

import fw2.model2.DbJoinKey;
import fw2.model2.Model2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Db Join Key</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DbJoinKeyImpl extends ModelElementImpl implements DbJoinKey {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected DbJoinKeyImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.DB_JOIN_KEY;
    }

} //DbJoinKeyImpl
