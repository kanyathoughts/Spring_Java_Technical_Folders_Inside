/**
 */
package fw2.model2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lookup</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fw2.model2.Model2Package#getLookup()
 * @model extendedMetaData="name='lookup' kind='elementOnly'"
 * @generated
 */
public interface Lookup extends Reference {
} // Lookup
