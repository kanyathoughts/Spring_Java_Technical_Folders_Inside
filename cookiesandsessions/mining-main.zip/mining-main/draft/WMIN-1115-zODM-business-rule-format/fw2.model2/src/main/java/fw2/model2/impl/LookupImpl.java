/**
 */
package fw2.model2.impl;

import fw2.model2.Lookup;
import fw2.model2.Model2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lookup</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LookupImpl extends ReferenceImpl implements Lookup {
	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	protected LookupImpl() {
        super();
    }

	/**
     * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
     * @generated
     */
	@Override
	protected EClass eStaticClass() {
        return Model2Package.Literals.LOOKUP;
    }

} //LookupImpl
