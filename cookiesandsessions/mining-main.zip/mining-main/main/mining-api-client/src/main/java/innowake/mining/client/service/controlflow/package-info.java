/* Copyright (c) 2019 innoWake gmbh Germany. All rights reserved. */
@innowake.lib.core.api.lang.NonNullByDefault
package innowake.mining.client.service.controlflow;